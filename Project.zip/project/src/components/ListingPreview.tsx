import React from 'react';
import { Package, Tag, CheckCircle } from 'lucide-react';
import type { ProductListing } from '../types';

interface ListingPreviewProps {
  listing?: ProductListing;
  onExport: () => void;
}

export default function ListingPreview({ listing, onExport }: ListingPreviewProps) {
  if (!listing) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6 flex items-center justify-center min-h-[200px]">
        <p className="text-gray-500 text-center">
          Enter your social media post details to generate an Amazon listing preview
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Package className="h-5 w-5 text-purple-600" />
        Amazon Listing Preview
      </h2>

      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">{listing.title}</h3>
          <div className="mt-2 flex items-center gap-2">
            <Tag className="h-4 w-4 text-gray-500" />
            <span className="text-lg font-bold text-gray-900">
              ${listing.price.toFixed(2)}
            </span>
          </div>
        </div>

        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">About this item</h4>
          <ul className="space-y-2">
            {listing.bulletPoints.map((point, index) => (
              <li key={index} className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-green-500 mt-1 flex-shrink-0" />
                <span className="text-sm text-gray-600">{point}</span>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">Product Description</h4>
          <p className="text-sm text-gray-600 whitespace-pre-wrap">{listing.description}</p>
        </div>

        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">Category</h4>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
            {listing.category}
          </span>
        </div>

        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">Search Terms</h4>
          <div className="flex flex-wrap gap-2">
            {listing.keywords.map((keyword, index) => (
              <span
                key={index}
                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
              >
                {keyword}
              </span>
            ))}
          </div>
        </div>
      </div>

      <button
        onClick={onExport}
        className="mt-6 w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
      >
        Export to Amazon
      </button>
    </div>
  );
}