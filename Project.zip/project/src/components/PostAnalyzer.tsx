import React, { useState } from 'react';
import { MessageSquare, AlertCircle, Loader } from 'lucide-react';
import type { SocialPost } from '../types';

interface PostAnalyzerProps {
  onAnalysis: (data: SocialPost) => void;
  isGenerating: boolean;
}

export default function PostAnalyzer({ onAnalysis, isGenerating }: PostAnalyzerProps) {
  const [url, setUrl] = useState('');
  const [platform, setPlatform] = useState<SocialPost['platform']>('instagram');
  const [content, setContent] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAnalysis({ platform, content, url });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <MessageSquare className="h-5 w-5 text-purple-600" />
        Analyze Social Media Post
      </h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Platform
          </label>
          <select
            value={platform}
            onChange={(e) => setPlatform(e.target.value as SocialPost['platform'])}
            className="mt-1 block w-full rounded-md border-gray-300 focus:border-purple-500 focus:ring-purple-500"
            disabled={isGenerating}
          >
            <option value="instagram">Instagram</option>
            <option value="tiktok">TikTok</option>
            <option value="youtube">YouTube</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Post URL
          </label>
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://..."
            className="mt-1 block w-full rounded-md border-gray-300 focus:border-purple-500 focus:ring-purple-500"
            required
            disabled={isGenerating}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Post Content
          </label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={4}
            className="mt-1 block w-full rounded-md border-gray-300 focus:border-purple-500 focus:ring-purple-500"
            placeholder="Paste your post content here..."
            required
            disabled={isGenerating}
          />
        </div>

        <div className="bg-yellow-50 p-4 rounded-md flex items-start gap-2">
          <AlertCircle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-yellow-700">
            Ensure your content complies with Amazon's listing policies. The AI will help optimize your listing while maintaining compliance.
          </p>
        </div>

        <button
          type="submit"
          disabled={isGenerating}
          className="w-full bg-purple-600 text-white py-2 px-4 rounded-md hover:bg-purple-700 transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isGenerating ? (
            <>
              <Loader className="h-5 w-5 animate-spin" />
              Generating Listing...
            </>
          ) : (
            'Generate Listing'
          )}
        </button>
      </form>
    </div>
  );
}