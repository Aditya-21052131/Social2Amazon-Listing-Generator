import React from 'react';
import { Sparkles, ShoppingBag } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-gradient-to-r from-purple-600 to-blue-600 text-white py-6 px-4">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-8 w-8" />
          <h1 className="text-2xl font-bold">Social2Amazon</h1>
        </div>
        <div className="flex items-center gap-2">
          <ShoppingBag className="h-6 w-6" />
          <span className="font-medium">Listing Generator</span>
        </div>
      </div>
    </header>
  );
}