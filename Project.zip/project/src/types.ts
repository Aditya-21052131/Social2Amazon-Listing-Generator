export interface ProductListing {
  title: string;
  description: string;
  bulletPoints: string[];
  category: string;
  keywords: string[];
  price: number;
}

export interface SocialPost {
  platform: 'instagram' | 'tiktok' | 'youtube';
  content: string;
  url: string;
}