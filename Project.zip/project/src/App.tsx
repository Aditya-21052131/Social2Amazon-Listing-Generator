import React, { useState } from 'react';
import Header from './components/Header';
import PostAnalyzer from './components/PostAnalyzer';
import ListingPreview from './components/ListingPreview';
import type { ProductListing, SocialPost } from './types';

function App() {
  const [listing, setListing] = useState<ProductListing>();
  const [isGenerating, setIsGenerating] = useState(false);

  const analyzeSocialPost = async (content: string) => {
    // Simulated AI analysis - in production, this would call your AI service
    const keywords = content.toLowerCase()
      .split(' ')
      .filter(word => word.length > 3)
      .slice(0, 5);

    const bulletPoints = [
      "100% ORGANIC: Pure and natural ingredients",
      "PREMIUM QUALITY: Highest grade available",
      "LAB TESTED: Third-party verified for purity",
      "SUSTAINABLY SOURCED: Environmentally conscious practices",
      "SATISFACTION GUARANTEED: Love it or your money back"
    ];

    return {
      title: "Premium Wellness Product",
      description: content.slice(0, 500) + "...",
      bulletPoints,
      category: "Health & Personal Care",
      keywords,
      price: 29.99
    };
  };

  const handleAnalysis = async (post: SocialPost) => {
    setIsGenerating(true);
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      const generatedListing = await analyzeSocialPost(post.content);
      setListing(generatedListing);
    } catch (error) {
      console.error('Error generating listing:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExport = async () => {
    if (!listing) return;
    
    // In production, this would integrate with Amazon's API
    alert('Listing ready for export to Amazon Seller Central!');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-6xl mx-auto py-8 px-4">
        <div className="grid md:grid-cols-2 gap-8">
          <PostAnalyzer onAnalysis={handleAnalysis} isGenerating={isGenerating} />
          <ListingPreview listing={listing} onExport={handleExport} />
        </div>
      </main>
    </div>
  );
}

export default App;